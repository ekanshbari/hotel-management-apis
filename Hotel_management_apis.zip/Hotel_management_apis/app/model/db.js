"user strict";

var mysql = require("mysql");

//local mysql db connection
var connection = mysql.createConnection({
  // host: "salesforecastenew.c8r6ywzced0r.eu-central-1.rds.amazonaws.com",
  host:"localhost",
  user: "root",
  password: "Ekansh@1",
  database: "arman"
});

connection.connect(function(err) {
  if (err) throw err;
});
module.exports = connection;




